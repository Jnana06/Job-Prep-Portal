<?php
require_once"dbconfig.php";
$c="1";
?>

 <form action="quizresult.php" method="POST"    enctype="multipart/form-data" >
<?php

 $t=select("SELECT * FROM question INNER JOIN options on question.QuestionID=options.QuestionID where question.status='1' AND question.cat_id='".$_REQUEST['id']."' order by rand() limit 20
");



while($y=mysqli_fetch_array($t))
{
	extract($y);
	echo" <div class='w3-container w3-myfont w3-blue'>
	<p><br>";
	
	echo" ";
		echo '<h3>Q.'.$c.''.$y['ques_text'].'</h3>';
		echo"</p>

</div>
<div class='w3-container'>
 ";

if(isset($y["option_1"])){ 


echo"<p>
  <input class='w3-radio' type='radio' value='1'   name='".$y['QuestionID']."' >
  <label>".$y['option_1']."</label></p>
<p>";

}


if(isset($y["option_2"])){ 

echo"
  <input class='w3-radio' type='radio' value='2'    name='".$y['QuestionID']."'>
  <label>".$y['option_2']."</label></p>
  <p>";
  
}

if(isset($y["option_3"])){ 

  echo"<input class='w3-radio' type='radio' value='3'    name='".$y['QuestionID']."'>
  <label>".$y['option_3']."</label></p>";
}


if(isset($y["option_4"])){ 
  echo"
  <input class='w3-radio' type='radio' value='4'    name='".$y['QuestionID']."'>
  <label>".$y['option_4']."</label></p></div>
 ";
}
$c++;
  echo"
  <input class='w3-radio' type='radio' style='display:none' value='no_attempt'    name='".$y['QuestionID']."' checked>



<div class='show'>


<input type='text'  id='show_ans' ux='".$Correct."' class='btn btn-success show_ans' value='show Answer' /></div>";

}
?>
</br>
<input type="submit" value="Get Result" class="btn hover-shadow hover-blue blue section btn-danger ripple w3-padding" /></center>
<p id='".$_REQUEST['id']."'>
</form>
<script>
$(document).on("click",".show",function() {
var p =$(this).children("#show_ans").attr("ux");
alert(p);
        
});
</script>