<?php
session_Start();
session_destroy();
echo"<script>alert('Logged Out');
		 window.location='index.php';
		 </script>";
?>