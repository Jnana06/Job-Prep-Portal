<?php 

include 'dbconfig.php';
$c=1;
?>

<!DOCTYPE HTML>
<html>
<head>
<title>JobPrep Portal</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Seeking Responsive web template"/>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
<script>
$(document).ready(function(){
	
	$('a').click(function(){
    var propty= $(this); 
    var action =propty.attr("data-action");
    });
});

	</script>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!----font-Awesome----->
</head>
<body>
<?php include"nav.php";?>
<?php
$result="0";
$n="0"; 
$v="0";
 foreach($_REQUEST as $a=>$p)
{
	
	
	$res=select("select * from options where QuestionID='".$a."'");
	while($t=mysqli_fetch_array($res))
	{
		if($t['ans']==$p)
		{
			$result++;
		}

			}
	if($p=="no_attempt"){
			   $n++;
		   }
	else
	{
		$v++;
}   
}
 	
?>
<!DOCTYPE html>
<html>
<title>LMT</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<head>


<div class="w3-content w3-padding-large w3-margin-top" style="top-margin:-2px;" >
<div class="w3-container   w3-margin-top" >
 
  
  <div class="w3-card-4">
    <div class="w3-container w3-center w3-red">
<p style="font-size:20px"><b>QUIZ RESULT</b></p>
<hr class="w3-border w3-bottombar w3-border-white">
	 
   
    </div>

    <div class="w3-container" >
   

      <p>
	        <label style="font-size:30px">Right answer = <?php echo $result ?></label>
      
	  <p> 
<hr class="w3-border w3-bottombar ">
 <p>
	        <label style="font-size:30px">Wrong Answer = <?php echo $v-$result ?></label>
      
	  <p> 
<hr class="w3-border w3-bottombar "> 
<p>
	        <label style="font-size:30px">Not Attempt = <?php echo $n ?> </label>
      
	  <p>   
      </div>
  </div>
</div></div>

</br>
</br>
</br>
</br>
</br>
</br>
<div class="container">
    <div class="single">  
	   <div class="col-md-10">
	   	  <div class="col_3">

	   	  	<h3 style="color:white; font-size:20pt; font-family:arial;">Correct Answers</h3>	
	   	  </div>
	   	  
<?php
 foreach($_REQUEST as $a=>$p)
{
$t=select("Select * from question where QuestionID='".$a."'");
$res1=select("select * from options where QuestionID='".$a."'");
while($y=mysqli_fetch_array($t))
{
	extract($y);
	echo" 
	<p><br>";
	
		echo '<h3  style="color:red; font-size:20pt; font-family:arial;">Q.'.$c.' '.$y['ques_text'].'</h3>';
while($y=mysqli_fetch_array($res1))
{
		echo" 
	<p><br>";
echo '<h3 style="color:green; font-size:20pt; font-family:arial;">ANS: '.$y['Correct'].'</h3>';

}
		

$c++;

}
}
?>
</div>
		  
	   	 
	   	  
	   	 
	 
  <div class="clearfix"> </div>
 </div>
</div>
    
    
      
      

<div class="footer_bottom">	
  <script>
	$(document).on("click", "a.deleteText", function() {
  
        
		var id=$(this).attr('ux');
		$.ajax({
			
			
			url:"app.php",
			method:"post",
		data:{id:id},
		datatype:"text",
		success:function(data)
		{
			$(pera).html(data);
			 $("#pera1").css("display","none");
		}
		});
    
});


$(document).on("click", "a.quiz", function() {
   
        
		var id=$(this).attr('ux');
	
		$.ajax({
			
			
			url:"quiz.php",
			method:"post",
		data:{id:id},
		datatype:"text",
		success:function(data)
		{
			$(pera1).html(data);
			$("#pera1").css("display","block");
		}
		});
    
});
</script>
  	
  	<div class="clearfix"> </div>
	<div class="copy">
		<p style="font-size:15pt;"><b><em> “ The best preparation for tomorrow is doing your best today. ”</em></b> </p>
	</div>
  </div>
</div>
</body>
</html>	
























