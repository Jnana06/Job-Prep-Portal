<?php
require_once"dbconfig.php";
 $query="select * from data  where id='".$_POST['id']."'";
$result=mysqli_query($cid,$query);
$output='';
while($res=mysqli_fetch_array($result))
{
	$output .='<p>'.$res['description'].'</p>';
}
echo $output;

?>