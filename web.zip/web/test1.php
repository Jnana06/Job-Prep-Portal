<?php
require_once"dbconfig.php";
 $query="select * from company  where id='".$_POST['id']."'";
$result=mysqli_query($cid,$query);
$output='';
while($res=mysqli_fetch_array($result))
{
	$output .='<div class="text-align:center">
	<img src="admin/images/'.$res['image'].'" style="height:100px"></div>
	<div class="well bg-success">'.$res['description'].'</div>';
}
echo $output;

?>