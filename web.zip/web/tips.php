<?php require_once"dbconfig.php";?>
<!DOCTYPE HTML>
<html>
<head>
<title>JobPrep Portal</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Seeking Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
<script>
$(document).ready(function(){
	//alert('aaaaaaaa');
	$('a').click(function(){
    var propty= $(this); 
    var action =propty.attr("data-action");
    });
});

	</script>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!----font-Awesome----->
</head>
<body>
<?php include"nav.php";?>

<div class="banner_1">
	<div class="container">
		<div id="search_wrapper1">
		   
		</div>
   </div> 
</div>	
<div class="container">
    <div class="single">  
	   <div class="col-md-12">
	   	  <div class="col_3">
		  <h3>1. Include a summary statement</h3>
		  <p style="text-align:justify">Resume objective statements, where you state exactly what career goals you 
		  wish to achieve, have mostly fallen out of fashion. This is largely because you want to focus on what you 
		  can do for the employer, not what the employer can do for you. A resume summary statement, on the other hand, 
		  sums up who you are professionally at the top of the page in a sentence or two and serves as the first impression
		  you give a hiring manager to entice them to keep reading.</p></br>
		 
	   	  <h3>2. Decide on a resume format</h3>
		  <p style="text-align:justify">There are a few dominant resume formats in use today: chronological, functional, 
		  and hybrid, which is a combination of the two. A chronological resume format lists a candidate's work experience
		  in reverse-chronological order. A functional resume format focuses on highlighting the candidate's skills and
		  achievements, rather than work experience. While the functional resume format can be an attractive option for 
		  job seekers with little experience, most employers prefer a chronological or hybrid resume format. Whatever resume
		  format you decide to use, be sure that your format remains consistent throughout the document.</p></br>
		  
		  <h3>3.  Pay attention to technical details</h3>
		  <p style="text-align:justify">When editing your resume, make sure there is no punctuation, grammatical, spelling,
		  or other errors that will make your resume look unprofessional. Then, have a friend or family member read it again
		  to catch any mistakes you might have missed — you can't afford a typo or missing word. Also, be sure to vary your
		  language and utilize action verbs throughout your resume to keep your reader engaged.</p></br>
		  <h3>4. Take stock of your achievements and activities</h3>
		  
		  <p style="text-align:justify">Make a list of absolutely everything you've done that might be useful on a resume.
		  From this list, you'll then need to narrow down what to actually include on your resume. Different things might be 
		  relevant to different jobs you apply for, so keep a full list and pick the most relevant things from it to include 
		  on your resume when you send it out.</p></br>
		  
		  <h3>5. Focus on your education and skills</h3>
		  <p style="text-align:justify">In lieu of work experience, it's best to expand and focus on your education and 
		  skills you've developed on your resume. What can you do well that this job requires? What will be useful to the
		  hiring company? What have you done in school and what have you studied that has prepared you for assuming this job?
		  This is generally a little easier if you're a college graduate with specialized education, but even a high school
		  graduate can talk about their electives, why they wanted to take them, and what they learned from the class.</p></br>
		  
		  <h3>6. Internships</h3>
		  <p style="text-align:justify">Paid and unpaid college internships are one of the best weapons you have against 
		  "experience required." Not only do they give you some real-world work experience, they also allow you to network 
		  and make connections that can put you in a job later. When applying for a job without experience, be sure to list 
		  any internships you completed. If you haven't had one, consider applying as a step before an entry-level job.</p></br>
		  
		  <h3>7. Include any extracurricular activities or volunteer work</h3>
		  <p style="text-align:justify">When surveyed, the majority of employers say that they take volunteer experience
		  into consideration alongside paid work experience. So any volunteer work that highlights your talents or where
		  you learned a new skill should be put on your resume. Only include hobbies if they are relevant to the position 
		  and have equipped you with transferable skills that would be useful for the job role.</p></br>
		  
		   <h3>8.Never include these certain elements</h3>
		  <p style="text-align:justify">While there are many elements you should consider adding to your resume, there are 
		  a few things you should never include on your resume because they waste space, don't tell the employer anything 
		  relevant, or could damage your personal brand. This list includes, but is not limited, to references, writing
		  samples, and photos of yourself. Do not add this information to your resume unless an employer or recruiter asks
		  you to provide them. In addition, make sure you're not using an unprofessional email address. 
		  “Kegmaster2017@email.com” may have sounded great when you were younger, but it's not the right message to send to
		  prospective employers. It's easy to create a free, professional-looking email address for your job-search activities
		  with platforms like Gmail.</p></br>
		  
		   <h3>9.Add a cover letter</h3>
		  <p style="text-align:justify">Even if one is not required, it's generally a good 
		  idea to send a short cover letter along with your resume. Cover letters are where
		  your personality comes out, and you need to use them to make the case for why you're the perfect 
		  candidate for this job. A standout cover letter can convince an employer to bring you in for an interview,
		  even if your resume itself doesn't have all the things they'd like to see.</p></br>
		  
		   <h3>10. Customize your resume for each job you apply to</h3>
		  <p style="text-align:justify">The last and most important thing to remember when creating a good resume is to 
		  customize it for every job to which you apply. Different job postings are going to have different keywords,
		  different job duties listed, and so on. Appealing to each individual employer's needs and job requirements is 
		  the best strategy for getting your application noticed.</p>
		  <p style="text-align:justify">At the end of the day, there's no magical formula for how to write a winning resume
		  — the only perfect resume is the one that gets you the job. Be prepared to tweak and update your resume, even when
		  you're comfortably employed. Utilize a hybrid resume format and focus on your skills and education when you don't
		  have any work experience to show. Sooner or later, you'll land that job — and gain that much-coveted experience.</p>
		  
		   </br>
		   </br>
		  
		  <p style="text-align:justify">Click on the following link for more <a href="https://www.topresume.com/career-advice/category/resume-and-cv">resume advice.</a></p>
		  
		   
		  
	
	 </div>
	 </div>
	 
	
  <div class="clearfix"> </div>
 </div>
</div>

<div class="footer_bottom">	
  
  	
  	<div class="clearfix"> </div>
	<div class="copy">
		<p style="font-size:15pt;"><b><em> “ The best preparation for tomorrow is doing your best today. ”</em></b> </p>
	</div>
  </div>
</div>
</body>
</html>	