<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{

	
}
else
{
	header("location:login.php");
}

?>
<!DOCTYPE HTML>
<html>
<?php include"head.php";?> 
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.html">Home</a></li>
<li class="active">Profile</li>
</ol>
</div>
<?php //print_r($_SESSION);?>
<div class="graph-visual tables-main">
<h2 class="inner-tittle">Profile</h2>
<div class="graph">
<div class="block-page">
<p>
<h3 class="inner-tittle two"></h3>
<div class="grid-1">
<div class="form-body">
<a href="view_profile.php"><button class="btn btn-info">View Profile 
</button> </a>
<a href="change_image.php"><button class="btn btn-info">Change Profile Picture 
</button></a> 
<a href="change_password.php"><button class="btn btn-info">Change Password
</button> 
</div>

</div>
</p>
</div>

</div>

</div>
</div>
<?php include"footer.php";?>

</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
</body>
</html>