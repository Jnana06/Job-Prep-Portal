<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{
	
}
else
{
	header("location:login.php");
}

?>
<!DOCTYPE HTML>
<html>
<?php include"head.php";?> 
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.html">Home</a></li>
<li class="active">Add Question</li>
</ol>
</div>
<div class="graph-visual tables-main">
<h2 class="inner-tittle">Select Any Category</h2>
<div class="graph">
<div class="block-page">
<div class="container">
<div class="row">
<div class="col-lg-4">
<form method="post" enctype="multipart/form-data"> 
IN English</br></br></br>

<input type="text" name="engopone" class="form-control" placeholder="Option-1" required></br>
<input type="text" name="engoptwo" class="form-control" placeholder="Option-2" required></br>
<input type="text" name="engopthree" class="form-control" placeholder="Option-3" required></br>
<input type="text" name="engopfour" class="form-control" placeholder="Option-4" required></br>

</div>
<div class="col-lg-4">

English Correct Answer</br></br></br>
<input type="checkbox" name="correctone" value="1" ></br></br></br>
<input type="checkbox" name="correcttwo" value="1"></br></br></br>
<input type="checkbox" name="correctthree" value="1"></br></br></br>
<input type="checkbox" name="correctfour" value="1"></br>

</div>

<input type="submit" name="submit" value="Sumbit" class="btn col-lg-9 btn-primary"  >
</form>






</div>
</div>

<?php
$engcoone = (isset($_REQUEST['correctone']));
    if ($engcoone == 1 )
      {
        $engcoone = 1;
      }
    else
     {
       $engcoone = 0;
     }
  // echo $engcoone;
   $engcotwo = (isset($_REQUEST['correcttwo']));
    if ($engcotwo == 1 )
      {
        $engcotwo = 1;
      }
    else
     {
       $engcotwo = 0;
     }
   //echo $engcotwo;
   $engcothree = (isset($_REQUEST['correctthree']));
    if ($engcothree == 1 )
      {
        $engcothree = 1;
      }
    else
     {
       $engcothree = 0;
     }
   //echo $engcothree;
   $engcothree = (isset($_REQUEST['correctfour']));
    if ($engcothree == 1 )
      {
        $engcothree = 1;
      }
    else
     {
       $engcothree = 0;
     }
   //echo $engcothree;
  
if(isset($_REQUEST['submit']))
{
	
extract($_REQUEST);
 
 $query="INSERT INTO `option`( `QuestionID`, `English`, `CorrectENG`)  
	VALUES ('$id','$engopone',b'$engcoone' ),
	('$id','$engoptwo',b'$engcotwo' ),
	('$id','$engopthree',b'$engcothree'),
	('$id','$engopfour',b'$engcothree' ) ";
	
	$n=iud($query);
	 if($n>=1)
	 {
		
		 echo"<script>alert('Options uploaded successfully');</script>";
		 echo "<script>window.location.href='question_view.php'</script>";
		 
		 
	 }
	
	
	else
	{
		echo"Something Wrong Try Again";
	}
}
?>


</div>

</div>

</div>
</div>
<?php include"footer.php"?>
</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
</body>
</html>