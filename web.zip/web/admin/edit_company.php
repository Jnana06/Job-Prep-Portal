<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{
	
}
else
{
	header("location:login.php");
}

?>
<!DOCTYPE HTML>
<html>
<?php include"head.php";?> 
<script type="text/javascript" src="nicEdit-latest.js"></script>
<script type="text/javascript">

  bkLib.onDomLoaded(function() {
        
        new nicEditor({fullPanel : true,maxHeight : 200}).panelInstance('area1');
  });

  </script>
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.php">Home</a></li>
<li class="active">Company</li>
</ol>
</div>
<div class="graph-visual tables-main">
<h2 class="inner-tittle" style="color:black;font-family:Times New Roman;">Company</h2>
<div class="graph" style="background-image:url('https://www.knoxalliance.store/wp-content/uploads/2017/05/light-color-background-images-for-website-top-hd-images-for-free-background-for-website-in-light-color-1-1024x640.jpg');">
<div class="block-page">
<p style="color:black;font-size:15pt;">Add Company

</p>
<?php
$t=select("select * from company where id='".$_REQUEST['id']."'");
while($q=mysqli_fetch_array($t))
{extract($q);
?>
<form method="post" enctype="multipart/form-data">
<input type="text" name="categoryname" class="form-control" value="<?=$name?>" placeholder="Type company.." style="color:black;"></br>
<p style="color:black;font-size:15pt;">Upload Image</p>
<input type="file" name="myfile" class="form-control" placeholder="Type company.." style="color:black;"></br>
<p style="color:black;font-size:15pt;">Description</p>
<textarea name="projectdis" id="area1" style="width:100%;height:2000px;" style="color:black;"><?=$description?>
 </textarea>

<input type="submit" class="btn btn-success" name="category" value="Update company"> 

</form><?php
}
?>
<?php
if(isset($_REQUEST['category']))
{
	extract($_REQUEST);
	$error=$_FILES["myfile"]["error"];

$name=$_FILES["myfile"]["name"];
$type=$_FILES["myfile"]["type"];
$size=$_FILES["myfile"]["size"];
$tmp_name=$_FILES["myfile"]["tmp_name"];
if(move_uploaded_file($tmp_name,"images/$name"))
{
	$n=iud("update company set `name`='$categoryname',`image`='$name',`description`='$projectdis' where id='".$_REQUEST['id']."'");
	if($n==1)
	{
		echo'<script>alert("Company Updated");
		window.location="view_company.php";
		</script>';
	}

}
else
{
	echo'<script>alert("No changes made.Please do necessary changes.");
		</script>';
}	
}

?>

</div>

</div>

</div>
</div>
<?php include"footer.php"?>
</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
</body>
</html>