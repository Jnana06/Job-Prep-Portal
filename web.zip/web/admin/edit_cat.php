<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{
	
}
else
{
	header("location:login.php");
}

?>
<!DOCTYPE HTML>
<html>
<?php include"head.php";?> 
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.php">Home</a></li>
<li class="active">category</li>
</ol>
</div>
<div class="graph-visual tables-main">
<h2 class="inner-tittle" style="font-family:Times New Roman;color:black;"> Update category</h2>
<div class="graph" style="background-image:url('https://www.knoxalliance.store/wp-content/uploads/2017/05/light-color-background-images-for-website-top-hd-images-for-free-background-for-website-in-light-color-1-1024x640.jpg');">
<div class="block-page">
<p style="color:black;font-size:15pt;">Update category

</p>
<?php
$re=select("select * from category where id='".$_REQUEST['id']."'");
while($r=mysqli_fetch_array($re))
{
	extract($r);

?>
<form method="post">
<input type="text" name="categoryname" value="<?=$category_name?>" class="form-control" placeholder="Type category.." style="color:black;">
<p style="color:black;font-size:15pt;"> Theory

</p>
<textarea name="theory" class="form-control" style="color:black;" ><?=$theory?></textarea></br>

<input type="submit" class="btn btn-success" name="ucategory" value="Update" style="background-color:#002561;"> 
</form>
<?php
}
if(isset($_REQUEST['ucategory']))
{
	extract($_REQUEST);
	$n=iud("update category set `category_name`= '$categoryname',`theory`='$theory' where id='".$_REQUEST['id']."'");
	if($n==1)
	{
		echo'<script>alert("Updated Successfully!");
		window.location="view_cat.php";
		</script>';
	}
	else
	{
	echo'<script>alert("No changes made.Please do necessary changes.");
		</script>';
	}
}

?>

</div>

</div>

</div>
</div>
<?php include"footer.php"?>
</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
</body>
</html>