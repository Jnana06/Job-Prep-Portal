<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{
	
}
else
{
	header("location:login.php");
}

?>
<!DOCTYPE HTML>
<html>
<?php include"head.php";?> 
<script type="text/javascript" src="nicEdit-latest.js"></script>
<script type="text/javascript">

  bkLib.onDomLoaded(function() {
        
        new nicEditor({fullPanel : true,maxHeight : 200}).panelInstance('area1');
  });

  </script>
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.html">Home</a></li>
<li class="active">Description</li>
</ol>
</div>
<div class="graph-visual tables-main">
<h2 class="inner-tittle">Description</h2>
<div class="graph">
<div class="block-page">
<p>Add Description

</p>

<form method="post">
<div class="form-group">choose any one
<select name="subject" class="form-control">
<option>choose any one</option>
<?php
$t=select("select * from subject where status='1'");
while($r=mysqli_fetch_array($t))
{extract($r);
?>
<option value="<?=$id?>"><?=$r['subject_name']?></option>
<?php
}
?>
<select></div><div class="form-group">Title
<input type="text" name="title" class="form-control" placeholder="Type price.."></div>
<textarea name="projectdis" id="area1" style="width:100%;height:2000px;">
 </textarea>

<input type="submit" class="btn btn-success" name="price" value="Add price"> 
</form>
<?php
if(isset($_REQUEST['price']))
{
	//echo"kjgfij";
	extract($_REQUEST);
	echo $q="INSERT INTO `data`( `subject_id`, `title`, `description`) VALUES  ('$subject','$title','$projectdis')";
	$n=iud($q);
	if($n==1)
	{
		echo'<script>alert(" Added");
		window.location="view_text.php";
		</script>';
	}
}

?>

</div>

</div>

</div>
</div>
<?php include"footer.php"?>
</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
</body>
</html>