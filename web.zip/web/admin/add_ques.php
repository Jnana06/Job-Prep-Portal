<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{
	
}
else
{
	header("location:login.php");
}
$query="select * from category";
$result=select($query);
?>
<!DOCTYPE HTML>
<html>
<?php include"head.php";?> 
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.html">Home</a></li>
<li class="active">Add Question</li>
</ol>
</div>
<div class="graph-visual tables-main">
<h2 class="inner-tittle">Select Any Category</h2>
<div class="graph">
<div class="block-page">
<div class="container">
<div class="row">
<?php
while($r=mysqli_fetch_array($result))
{extract($r);
?>
<a href="question.php?catid=<?=$CategoryID?>"><div class="col-lg-3 btn btn-primary"><?=ucwords($Name)?></div></a>
<?php
}
?>






</div>
</div>



</div>

</div>

</div>
</div>
<?php include"footer.php"?>
</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
</body>
</html>