<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{

	
}
else
{
	header("location:login.php");
}

?>
<!DOCTYPE HTML>
<html>
<head>
<?php include"head.php";?> 
<script type="text/javascript" src="js/nicEdit-latest.js"></script>
<script type="text/javascript">

  bkLib.onDomLoaded(function() {
        
        new nicEditor({fullPanel : true,maxHeight : 200}).panelInstance('area1');
  });

  </script>
  </head>
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.html">Home</a></li>
<li class="active">add Blog</li>
</ol>
</div>
<div class="graph-visual tables-main">
<h2 class="inner-tittle">Add Blog</h2>
<div class="graph">
<div class="block-page">
<p>
<h3 class="inner-tittle two">BLOG</h3>

<div class="form-body">
<?php
$result=select("select * from blog where blogid='".$_REQUEST['id']."'");
while($r=mysqli_fetch_array($result))
{
	extract($r);


?>
<form class="form-horizontal" action="myphp.php" method="post" enctype="multipart/form-data"> 
<div class="form-group"> 
<label for="inputEmail3" id="errormetadis" class="col-sm-2 control-label">Category</label> 
<div class="col-xs-6">
<select  name="ucategory">
<option>Select Category</option>
<option value="PHP">PHP</option>
<option value="JAVA">JAVA</option>
<option value="ANDROID">ANDROID</option>
<option value="MATLAB">MATLAB</option>
<option value="privacy">PRIVACY PRESERVING</option>
<option value="datamining">DATA MINING</option>
<option value="webmining">WEB MINING</option>
<option value="textmining">TEXT MINING</option>
<option value="geospatial">GEOSPATIAL</option>
<option value="socialmedia">SOCIAL MEDIA</option>
<option value="videoprocessing">VIDEO PROCESSING</option>
<option value="imageprocessing">IMAGE PROCESSING</option>
<option value="audioprocessing">AUDIO PROCESSING</option>
<option value="routing">ROUTING</option>
<option value="clustering">CLUSTERING</option>
<option value="attacks">ATTACKS</option>

</select>
</div> 
</div>
<div class="form-group">
<label for="inputPassword3" id="errortitle" class="col-sm-2 control-label">Title</label> 
<div class="col-xs-6"> 
<input type="text" class="form-control" value="<?=$title?>" id="title" name='utitle' placeholder="Title"> 
</div>
</div>
<div class="form-group">
<label for="inputPassword3" id="errormetakey"   class="col-sm-2 control-label">Meta Keyword</label> 
<div class="col-xs-6"> 
<input type="text" class="form-control" id="metakey" value="<?=$keyword?>" name='umetakey' placeholder="Keyword"> 
</div>
</div>
<div class="form-group"> 
<label for="inputEmail3" id="errormetadis"  class="col-sm-2 control-label">Short Discription</label> 
<div class="col-xs-6">
<input type="text" class="form-control" name="ushortdis" value="<?=$short_dis?>" placeholder="discription"> 
</div> 
</div>
<div class="form-group"> 
<label for="inputEmail3" id="image" class="col-sm-2 control-label">Blog Image</label> 
<div class="col-xs-6">
<input type="file" class="form-control col-xs-4" id="image"  name="uimage" > 
<input type="hidden"   value="<?=$blogid?>" name="ublogid" > 
</div> 
</div>



<div class="form-group"> 
<label for="inputEmail3" id="cpassworderror" class="col-sm-2 control-label">Blog Discription</label> 
<div class="col-sm-12">
 <textarea name="ublogdis" id="area1" style="width:70%;height:200px;"><?=$blog_dis?>
 </textarea>
 </div>
 </div>
<div class="col-sm-4"> 
<input type="submit" class="btn btn-info btn-block" name="update_blog"  value="UPDATE BLOG"> </div> </form> 
</div>

<?php
}
?>
</p>
</div>

</div>

</div>
</div>
<?php include"footer.php";?>

</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
</body>
</html>