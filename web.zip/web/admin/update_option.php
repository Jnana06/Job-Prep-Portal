<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{
	
}
else
{
	header("location:login.php");
}

?>
<!DOCTYPE HTML>
<html>
<?php include"head.php";?> 
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.html">Home</a></li>
<li class="active">Add Question</li>
</ol>
</div>
<div class="graph-visual tables-main">
<h2 class="inner-tittle">Select Any Category</h2>
<div class="graph">
<div class="block-page">
<div class="container">
<div class="row">
<div class="col-lg-4">
<form method="post" enctype="multipart/form-data"> 
IN English</br></br>

<input type="text" name="engopone" class="form-control" placeholder="Option-1" required></br>
<input type="text" name="engoptwo" class="form-control" placeholder="Option-2" required></br>
<input type="text" name="engopthree" class="form-control" placeholder="Option-3" required></br>
<input type="text" name="engopfour" class="form-control" placeholder="Option-4" required></br>

</div>
<div class="col-lg-4">
IN Hindi</br></br>

<input type="text" name="hindiopone" class="form-control" placeholder="Option-1" required></br>
<input type="text" name="hindioptwo" class="form-control" placeholder="Option-2" required></br>
<input type="text" name="hindiopthree" class="form-control" placeholder="Option-3" required></br>
<input type="text" name="hindiopfour" class="form-control" placeholder="Option-4" required></br>

</div>
<div class="col-lg-4">

Click On The Correct Answer</br></br>
<input type="checkbox" name="correctone" value="1" ></br></br></br>
<input type="checkbox" name="correcttwo" value="1"></br></br></br>
<input type="checkbox" name="correctthree" value="1"></br></br></br>
<input type="checkbox" name="correctfour" value="1"></br>

</div>

<input type="submit" name="submit" value="Sumbit" class="btn col-lg-9 btn-primary"  >
</form>






</div>
</div>

<?php
$coone = (isset($_REQUEST['correctone']));
    if ($coone == 1 )
      {
        $coone = 1;
      }
    else
     {
       $coone = 0;
     }
   echo $coone;
   $cotwo = (isset($_REQUEST['correcttwo']));
    if ($cotwo == 1 )
      {
        $cotwo = 1;
      }
    else
     {
       $cotwo = 0;
     }
   echo $cotwo;
   $cothree = (isset($_REQUEST['correctthree']));
    if ($cothree == 1 )
      {
        $cothree = 1;
      }
    else
     {
       $cothree = 0;
     }
   echo $cothree;
   $cofour = (isset($_REQUEST['correctfour']));
    if ($cofour == 1 )
      {
        $cofour = 1;
      }
    else
     {
       $cofour = 0;
     }
   echo $cofour;
if(isset($_REQUEST['submit']))
{
	
extract($_REQUEST);
 
	echo $query="INSERT INTO `option`( `QuestionID`, `English`, `Hindi`, `Correct`)  
	VALUES ('$questionid','$engopone','$hindiopone',b'$coone' ),('$questionid','$engoptwo','$hindioptwo',b'$cotwo' ),
	('$questionid','$engopthree','$hindiopthree',b'$cothree' ),('$questionid','$engopfour','$hindiopfour',b'$cofour' ) ";
	 //$query="update `option` set QuestionID='$questionid', English='$engopone', Hindi='$hindiopone', Correct=b'$coone' "
	
	
	$n=iud($query);
	 if($n!=0)
	 {
		
		 echo"<script>alert('Options uploaded successfully');</script>";
		 echo "<script>window.location.href='question_view.php'</script>";
		 
		 
	 }
	
	
	else
	{
		echo"Something Wrong Try Again";
	}
}
?>


</div>

</div>

</div>
</div>
<?php include"footer.php"?>
</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
</body>
</html>