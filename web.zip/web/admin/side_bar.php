<div class="sidebar-menu">
<header class="logo">
<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="index.php"> <span id="logo"> <h1>ADMIN</h1></span> 
<!--<img id="logo" src="" alt="Logo"/>--> 
</a> 
</header>
<div style="border-top:1px solid rgba(69, 74, 84, 0.7)"></div>
<!--/down-->
	


<!--//down-->
<div class="menu">
<ul id="menu" >
<?php
if(isset($_SESSION['login']))
{
	?>

<li><a href="user.php"><i class="fa fa-tachometer"></i> <span>Manage Registered User</span></a></li>
<li><a href="add_subject.php"><i class="fa fa-tachometer"></i> <span>Add Subject</span></a></li>
<li><a href="view_subject.php"><i class="fa fa-tachometer"></i> <span>View Subject</span></a></li>
<li><a href="add_cat.php"><i class="fa fa-tachometer"></i> <span>Add Category</span></a></li>
<li><a href="view_cat.php"><i class="fa fa-tachometer"></i> <span>View Category</span></a></li>
<li><a href="add_company.php"><i class="fa fa-tachometer"></i> <span>Add Company</span></a></li>
<li><a href="view_company.php"><i class="fa fa-tachometer"></i> <span>View Company</span></a></li>

<li><a href="add_text.php"><i class="fa fa-tachometer"></i> <span>Add data</span></a></li>
<li><a href="view_text.php"><i class="fa fa-tachometer"></i> <span>View data</span></a></li>
<li><a href="question_english.php"><i class="fa fa-tachometer"></i> <span>Add Questions</span></a></li>
<li><a href="ques_view_eng.php"><i class="fa fa-tachometer"></i> <span>View Questions</span></a></li>
<li><a href="logout.php"><i class="fa fa-tachometer"></i> <span>Logout</span></a></li>
<!--<li><a href="enquiry.php"><i class="fa fa-tachometer"></i> <span>Download Enquiries</span></a></li>
<li><a href="project.php"><i class="fa fa-tachometer"></i> <span>Add New Project</span></a></li>
<li><a href="view_project_list.php"><i class="fa fa-tachometer"></i> <span>View Project List</span></a></li>
<li><a href="blog.php"><i class="fa fa-tachometer"></i> <span>Add New Blog</span></a></li>
<li><a href="view_blog_list.php"><i class="fa fa-tachometer"></i> <span>View Blog List</span></a></li>
<li><a href="change_image.php"><i class="fa fa-tachometer"></i> <span>Change Image</span></a></li>-->


<?php }else{ ?>
<li><a href="login.php"><i class="fa fa-tachometer"></i> <span>Login</span></a></li>
<!--<li><a href="forget_password.php"><i class="fa fa-tachometer"></i> <span>Forget Password</span></a></li>-->
<?php } ?>
</ul>
</div>
</div>