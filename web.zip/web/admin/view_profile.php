<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{

	
}
else
{
	header("location:login.php");
}
$r=select("select * from user");
?>
<!DOCTYPE HTML>
<html>
<?php include"head.php";?> 
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.html">Home</a></li>
<li class="active">Profile</li>
</ol>
</div>
<?php //print_r($_SESSION);?>
<div class="graph-visual tables-main">
<h2 class="inner-tittle">Profile</h2>


<p>
<?php 
while($s=mysqli_fetch_array($r))
{
	extract($s);
}
?>
<div class="col-lg-4">
<table class="table">
<tr><td>Name  --</td><td><?=ucwords($name)?></td></tr>
<tr><td>Email  --</td><td><?=$email?></td></tr>
<tr><td>Mobile  --</td><td><?=$mobile?></td></tr>
<tr><td>Password  --</td><td><?=$password?></td></tr>
<tr><td>Profile Image  --</td><td><img src="images/<?=$image?>" style="height:50px;border-radius: 50%;"></td></tr>
<table>
</div>

</p>




</div>
</div>
<?php include"footer.php";?>

</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
</body>
</html>