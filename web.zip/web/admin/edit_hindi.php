<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{

	
}
else
{
	header("location:login.php");
}
$qid=$_REQUEST['qid'];
$query="SELECT DISTINCT `category`.*,CASE WHEN IFNULL(`question_detail`.`QuestionDetailID`,0)>0 THEN 1 ELSE 0 END AS Checked  FROM `category` LEFT OUTER JOIN `question_detail` ON (`question_detail`.`QuestionID`='$qid' AND `question_detail`.`CategoryID`=`category`.`CategoryID` AND `question_detail`.`Status`=1)";
$result=select($query);

?>
<!DOCTYPE HTML>
<html>
<head>
<?php include"head.php";?> 
<script type="text/javascript" src="js/nicEdit-latest.js"></script>
<script type="text/javascript">

  bkLib.onDomLoaded(function() {
        
        new nicEditor({fullPanel : true,maxHeight : 200}).panelInstance('area1');
  });

  </script>
  
  
  <script>
	function abc(num)
	{
		alert(num);
	}
	</script>
  
  </head>
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.html">Home</a></li>
<li class="active">Update project</li>
</ol>
</div>
<div class="graph-visual tables-main">
<h2 class="inner-tittle">Update Hindi Question</h2>


<p>


<div class="container">
<div class="row">
<div class="col-lg-6">
<form method="post" enctype="multipart/form-data">
<?php
$q1=select("select * from question where QuestionID='".$qid."'");
while($r1=mysqli_fetch_array($q1))
{
	extract($r1);
	?>
	
	<!--
	<input type="checkbox"  name="category[]" value="" />&nbsp;&nbsp;&nbsp;
-->
	



Type in Hindi-
<input type="text" name="hindi" class="form-control" value="<?=$Hindi?>"  placeholder="Question in Hindi" required></br>
Time-
<input type="text" name="time" class="form-control" value="<?=$Time?>"  placeholder="Question in Hindi" required></br>

<?php
}
?> 
image-

<input type="file" name="image" class="form-control" ></br>

</div>
<div class="col-lg-6">
<p style="font-weight:bold">Select Category--</p>
<?php
while($r=mysqli_fetch_array($result))
{
	extract($r);
	?>
	
	
	
	<input type="checkbox"   name="category[]" <?php echo (($Checked==1)?"checked":""); ?> id="<?=$CategoryID?>" value="<?=$CategoryID?>" /><?=$Name?>&nbsp;&nbsp;&nbsp;

	<?php
}
?>
</br></br>
<p style="font-weight:bold">Select Price--</p>
<?php
$all_price=select("SELECT DISTINCT `price`.*,CASE WHEN IFNULL(`question_detail`.`QuestionDetailID`,0)>0 THEN 1 ELSE 0 END AS Checked  FROM `price` LEFT OUTER JOIN `question_detail` ON (`question_detail`.`QuestionID`='$qid' AND `question_detail`.`PriceID`=`price`.`PriceID`  AND `question_detail`.`Status`=1)");
while($all_p=mysqli_fetch_array($all_price))
{
	extract($all_p);
?>
<input type="checkbox" name="newprice[]" <?php echo (($Checked==1)?"checked":""); ?> id="<?php echo $PriceID?>"  value="<?=$PriceID?>">  <?php echo ucwords($Price);?>/-&nbsp;&nbsp;&nbsp;
<?php
	
	
}
?>
	



</br></br>	<img src="images/<?=$Image?>" style="height:100px">
	
	
	
	
	
	
	

	
	
	


	
	
	
</div>
</div>
<div class="row">

<div>


<?php
/*
$s1=select("SELECT * FROM `option` WHERE `QuestionID`='".$qid."'");

//$i=1;
while($rs1=mysqli_fetch_array($s1))
{
	//echo 'fghajdsssss';
extract($rs1);
	
	if($rs1['optionname']=='answer1')
	{ 
if($rs1['CorrectEng']==1){
	
	
echo '<input type="checkbox"    name="correctone" value="1" checked></br></br></br>';
	
}else{
	
	
echo '<input type="checkbox"    name="correctone" value="1" ></br></br></br>';
}
		
	}
	if($rs1['optionname']=='answer2')
	{ 
if($rs1['CorrectEng']==1){
	
	
echo '<input type="checkbox"    name="correcttwo" value="1" checked></br></br></br>';
	
}else{
	
	
echo '<input type="checkbox"    name="correcttwo" value="1" ></br></br></br>';
}
		
	}
	if($rs1['optionname']=='answer3')
	{ 
if($rs1['CorrectEng']==1){
	
	
echo '<input type="checkbox"    name="correctthree" value="1" checked></br></br></br>';
	
}else{
	
	
echo '<input type="checkbox"    name="correctthree" value="1" ></br></br></br>';
}
		
	}
	if($rs1['optionname']=='answer4')
	{ 
if($rs1['CorrectEng']==1){
	
	
echo '<input type="checkbox"    name="correctfour" value="1" checked></br></br></br>';
	
}else{
	
	
echo '<input type="checkbox"    name="correctfour" value="1" ></br></br></br>';
}
		
	}
	
}*/
//echo $optionname;
?>


<div class="col-lg-4">
HINDI-</br></br>
<?php

$s2=select("SELECT * FROM `options` WHERE `QuestionID`='".$qid."' and optionname='answer1'");
//$i=1;
while($rs2=mysqli_fetch_array($s2))
{extract($rs2);
	?>
	<input type="hidden"  name="hindi1id" value='<?=$OptionsID?>'class="form-control" placeholder="Option-1" required></br>
	<input type="text"  name="hindioption1" value='<?=$Hindi?>'class="form-control" placeholder="Option-1" required></br>
<?php
}
?>
<?php

$s2=select("SELECT * FROM `options` WHERE `QuestionID`='".$qid."' and optionname='answer2'");
//$i=1;
while($rs2=mysqli_fetch_array($s2))
{extract($rs2);
	?>
	<input type="hidden"  name="hindi2id" value='<?=$OptionsID?>'class="form-control" placeholder="Option-1" required></br>
	<input type="text"  name="hindioption2" value='<?=$Hindi?>'class="form-control" placeholder="Option-1" required></br>
<?php
}
?>
<?php

$s2=select("SELECT * FROM `options` WHERE `QuestionID`='".$qid."' and optionname='answer3'");
//$i=1;
while($rs2=mysqli_fetch_array($s2))
{extract($rs2);
	?>
	<input type="hidden"  name="hindi3id" value='<?=$OptionsID?>'class="form-control" placeholder="Option-1" required></br>
	<input type="text"  name="hindioption3" value='<?=$Hindi?>'class="form-control" placeholder="Option-1" required></br>
<?php
}
?>
<?php

$s2=select("SELECT * FROM `options` WHERE `QuestionID`='".$qid."' and optionname='answer4'");
//$i=1;
while($rs2=mysqli_fetch_array($s2))
{extract($rs2);
	?><input type="hidden"  name="hindi4id" value='<?=$OptionsID?>'class="form-control" placeholder="Option-1" required></br>
	<input type="text"  name="hindioption4" value='<?=$Hindi?>'class="form-control" placeholder="Option-1" required></br>
<?php
}
?>
</div>

</div>
<div class="col-lg-1">
Correct-</br></br></br>
<?php

$s1=select("SELECT * FROM `options` WHERE `QuestionID`='".$qid."'");
//$i=1;
while($rs1=mysqli_fetch_array($s1))
{
	//echo 'fghajdsssss';
extract($rs1);
	//print_r($optionname);
	if($rs1['optionname']=='answer1')
	{ 
if($rs1['Correct']==1){
	
	
echo '<input type="checkbox"    name="correctonehindi" value="1" checked></br></br></br></br>';
	
}else{
	
	
echo '<input type="checkbox"    name="correctonehindi" value="1" ></br></br></br></br>';
}
		
	}
	if($rs1['optionname']=='answer2')
	{ 
if($rs1['Correct']==1){
	
	
echo '<input type="checkbox"    name="correcttwohindi" value="1" checked></br></br></br></br>';
	
}else{
	
	
echo '<input type="checkbox"    name="correcttwohindi" value="1" ></br></br></br></br>';
}
		
	}
	if($rs1['optionname']=='answer3')
	{ 
if($rs1['Correct']==1){
	
	
echo '<input type="checkbox"    name="correctthreehindi" value="1" checked></br></br></br></br>';
	
}else{
	
	
echo '<input type="checkbox"    name="correctthreehindi" value="1" ></br></br></br></br>';
}
		
	}
	if($rs1['optionname']=='answer4')
	{ 
if($rs1['Correct']==1){
	
	
echo '<input type="checkbox"    name="correctfourhindi" value="1" checked></br></br></br></br>';
	
}else{
	
	
echo '<input type="checkbox"    name="correctfourhindi" value="1" ></br></br></br></br>';
}
		
	}
	
}
//echo $optionname;
?></div>
<input type="submit" name="submit" value="Update" class="btn  col-lg-10 btn-primary"  >
</form>

</p>

<?php
if(isset($_REQUEST['submit']))
{
	//$name="NULL";
	$error=$_FILES["image"]["error"];

$name=$_FILES["image"]["name"];
$type=$_FILES["image"]["type"];
$size=$_FILES["image"]["size"];
$tmp_name=$_FILES["image"]["tmp_name"];
  

	move_uploaded_file($tmp_name,"images/$name");
	
	extract($_REQUEST);
	
	//echo $hindi;
	//print_r($category);
	//print_r($newprice);
              $query="UPDATE `question` SET `Hindi`='$hindi',`Image`='$name',`Time`='$time' WHERE QuestionID='".$qid."'";     
               $n=iud($query);
	
		 
		$check=implode(", ", $_POST['category']);
		$check1 = explode(',', $check);
		$q=$qid;
 $p=implode(", ", $_POST['newprice']);
 $ps = explode(',', $p);
 iud("UPDATE `question_detail` SET `Status`=b'0' WHERE `QuestionID`=$qid");
foreach ($ps as $p )

{
	foreach ($check1 as $check )
	{
		
$T="CALL `update_question`($qid,$check,$p, 1);";
	    iud($T);
	}
	}

            //$query="INSERT INTO `queswcat`( `Priceid`, `Categoryid`, `Questionid`) VALUES 
		      
         //$del=iud("delete from `options` where QuestionID='".$qid."'");
		      

		 /*$engcoone = (isset($_REQUEST['correctone']));
    if ($engcoone == 1 )
      {
        $engcoone = 1;
      }
    else
     {
       $engcoone = 0;
     }
  // echo $engcoone;
   $engcotwo = (isset($_REQUEST['correcttwo']));
    if ($engcotwo == 1 )
      {
        $engcotwo = 1;
      }
    else
     {
       $engcotwo = 0;
     }
   //echo $engcotwo;
   $engcothree = (isset($_REQUEST['correctthree']));
    if ($engcothree == 1 )
      {
        $engcothree = 1;
      }
    else
     {
       $engcothree = 0;
     }
   //echo $engcothree;
   $engcofour = (isset($_REQUEST['correctfour']));
    if ($engcofour == 1 )
      {
        $engcofour = 1;
      }
    else
     {
       $engcofour = 0;
     }*/
   //echo $engcothree;
   $hindicoone = (isset($_REQUEST['correctonehindi']));
    if ($hindicoone == 1 )
      {
        $hindicoone = 1;
      }
    else
     {
       $hindicoone = 0;
     }
  // echo $hindicoone;
   $hindicotwo = (isset($_REQUEST['correcttwohindi']));
    if ($hindicotwo == 1 )
      {
        $hindicotwo = 1;
      }
    else
     {
       $hindicotwo = 0;
     }
   //echo $hindicotwo;
   $hindicothree = (isset($_REQUEST['correctthreehindi']));
    if ($hindicothree == 1 )
      {
        $hindicothree = 1;
      }
    else
     {
       $hindicothree = 0;
     }
   //echo $hindicothree;
  $hindicofour = (isset($_REQUEST['correctfourhindi']));
    if ($hindicofour == 1 )
      {
        $hindicofour = 1;
      }
    else
     {
       $hindicofour = 0;
     }
     
     
     	  $upe1="update options set  Hindi='$hindioption1',Correct=b'$hindicoone' where  OptionsID='$hindi1id'";
	 $upe2="update options set  Hindi='$hindioption2',Correct=b'$hindicotwo' where   OptionsID='$hindi2id'";
	 $upe3="update options set  Hindi='$hindioption3',Correct=b'$hindicothree' where   OptionsID='$hindi3id'";
	 $upe4="update options set  Hindi='$hindioption4',Correct=b'$hindicofour' where  OptionsID='$hindi4id'";
	 
	 
	
	$n1=iud($upe1);
	if($n1>=0)
	{
		$n2=iud($upe2);
		if($n2>=0)
		{
			$n3=iud($upe3);
			if($n3>=0)
			{
				$n4=iud($upe4);
				if($n4>=0)
				{
					 echo"<script>alert(' Update successfully');</script>";
		 echo "<script>window.location.href='ques_view_hindi.php'</script>";
		 
				}
				else
	{
		echo"Something Wrong Try Again wwwwww1";
	}
			}
			else
	{
		echo"Something Wrong Try Again wwwwww2";
	}
				
		}
		else
	{
		echo"Something Wrong Try Again wwwwww3";
	}
	
	}
	else
	{
		echo"Something Wrong Try Again wwwwww4";
	}
}
?>



</div>
</div>
<?php include"footer.php";?>

</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
<!--<script>

$(document).ready(function(){
	
$("#project_submit").click(function(){
	
var valid=true;
var title=$.trim($("#title").val());
var metakey=$.trim($("#metakey").val());
var metadis=$.trim($("#metadis").val());

if(title.length<6)
{
$("#errortitle").html('Invalid title');
$("#errortitle").css("color","red");
$("#title").css("border-color","red");
valid=false;
}
else
{
$("#errortitle").html('Title');
$("#errortitle").css("color","black");
$("#title").css("border-color","#ddd");
}
if(metakey.length<6)
{
$("#newpassworderror").html('Invalid New Password');
$("#newpassworderror").css("color","red");
$("#newpassword").css("border-color","red");
valid=false;
}
else
{
$("#newpassworderror").html('New Password');
$("#newpassworderror").css("color","black");
$("#newpassword").css("border-color","#ddd");
}
if(metadis.length<6)
{
$("#newpassworderror").html('Invalid New Password');
$("#newpassworderror").css("color","red");
$("#newpassword").css("border-color","red");
valid=false;
}
else
{
$("#newpassworderror").html('New Password');
$("#newpassworderror").css("color","black");
$("#newpassword").css("border-color","#ddd");
}



var mymethod="post";
var myurl="myphp.php";
var mydata="oldpassword="+oldpassword+"&newpassword="+newpassword+"&cpassword="+cpassword+"&change=yes";

$.ajax({
	
	method:mymethod,
	url:myurl,
	data:mydata,
	success:function(result)
	{
		if(result==1)
		{
	        alert("Password Changed Successfully");
			$("#oldpassword").val("");
			$("#newpassword").val("");
			$("#cpassword").val("");
		}
		else
		{
			alert(result);
		}
			
		
	}
});	






return false;
});
});














</script>-->
























</body>
</html>