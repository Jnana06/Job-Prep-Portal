<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{

	
}
else
{
	header("location:login.php");
}
$qid=$_REQUEST['qid'];
$query="SELECT DISTINCT `category`.*,CASE WHEN IFNULL(`question_detail`.`QuestionDetailID`,0)>0 THEN 1 ELSE 0 END AS Checked  FROM `category` LEFT OUTER JOIN `question_detail` ON (`question_detail`.`QuestionID`='$qid' AND `question_detail`.`CategoryID`=`category`.`CategoryID` AND `question_detail`.`Status`=1)";
$result=select($query);


?>
<!DOCTYPE HTML>
<html>
<head>
<?php include"head.php";?> 
<script type="text/javascript" src="js/nicEdit-latest.js"></script>
<script type="text/javascript">

  bkLib.onDomLoaded(function() {
        
        new nicEditor({fullPanel : true,maxHeight : 200}).panelInstance('area1');
  });

  </script>
  
  
  <script>
	function abc(num)
	{
		alert(num);
	}
	</script>
  
  </head>
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.php">Home</a></li>
<li class="active">Update question</li>
</ol>
</div>
<div class="graph-visual tables-main" style="background-image:url('https://www.knoxalliance.store/wp-content/uploads/2017/05/light-color-background-images-for-website-top-hd-images-for-free-background-for-website-in-light-color-1-1024x640.jpg');">
<h2 class="inner-tittle" style="font-family:Times New Roman;">Update  Question</h2>


<p>


<div class="container">
<div class="row">
<div class="col-lg-6">
<form method="post" enctype="multipart/form-data">
<?php
$q1=select("select * from question where QuestionID='".$qid."'");
while($r1=mysqli_fetch_array($q1))
{
	extract($r1);
	?>
	
	<!--
	<input type="checkbox"  name="category[]" value="" />&nbsp;&nbsp;&nbsp;
-->
	


<p style="font-size:13pt;color:black;">Type question</p>
<input type="text" name="english" class="form-control"  value="<?=$ques_text?>" placeholder="Question in English" required style="color:black;"></br>
<?php
}
?> 


</div>

</div>
<div class="row">
<div class="col-lg-4">
<p style="font-size:13pt;color:black;">Options</p>

<?php

$s2=select("SELECT * FROM `options` WHERE `QuestionID`='".$qid."' ");
//$i=1;
while($rs2=mysqli_fetch_array($s2))
{extract($rs2);
	?>
	<input type="text"  name="option_1" value='<?=$option_1?>'class="form-control" placeholder="Option-1" required style="color:black;"></br>
	<input type="text"  name="option_2" value='<?=$option_2?>'class="form-control" placeholder="Option-1" required style="color:black;"></br>
	<input type="text"  name="option_3" value='<?=$option_3?>'class="form-control" placeholder="Option-1" required style="color:black;"></br>
	<input type="text"  name="option_4" value='<?=$option_4?>'class="form-control" placeholder="Option-1" required style="color:black;"></br>
	

</div>

<div>
<div class="col-lg-2">
<p style="font-size:13pt;color:black;">Correct answer</p>
<input type="text"  name="correct" value='<?=$Correct?>'class="form-control" placeholder="Option-1" required style="color:black;"></br>
<p style="font-size:13pt;color:black;">Number of Correct Answer</p>
<input type="text"  name="ans" value='<?=$ans?>'class="form-control" placeholder="" required style="color:black;"></br>
<?php
}
?>



</div>


</div>

<input type="submit" name="submit" value="Update" class="btn  col-lg-10 btn-primary"  >
</form>

</p>

<?php
if(isset($_REQUEST['submit']))
{
	
	
	extract($_REQUEST);
	echo $english;
	
	//print_r($category);
	//print_r($newprice);
              $query="UPDATE `question` SET `ques_text`='$english' WHERE QuestionID='".$qid."'";     
               $n=iud($query);
	
	
		 
		
		$q=$qid;
 

  ?>
  
	 	</br>
<?php		 $upe1="update options set option_1='$option_1',`option_2`='$option_2', `option_3`='$option_3'
,`option_4`='$option_4',`Correct`='$correct' ,`ans`='$ans' where  QuestionID='$qid'";
	 $n1=iud($upe1);
	if($n1>=0)
	{
		
					 echo"<script>alert(' Update successfully');</script>";
		 echo "<script>window.location.href='ques_view_eng.php'</script>";
		 
				
	
	
	}
	else
	{
		echo"Something Wrong Try Again wwwwww4";
	}
	
	
	 
		 
	
}
?>



</div>
</div>
<?php include"footer.php";?>

</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
<!--<script>

$(document).ready(function(){
	
$("#project_submit").click(function(){
	
var valid=true;
var title=$.trim($("#title").val());
var metakey=$.trim($("#metakey").val());
var metadis=$.trim($("#metadis").val());

if(title.length<6)
{
$("#errortitle").html('Invalid title');
$("#errortitle").css("color","red");
$("#title").css("border-color","red");
valid=false;
}
else
{
$("#errortitle").html('Title');
$("#errortitle").css("color","black");
$("#title").css("border-color","#ddd");
}
if(metakey.length<6)
{
$("#newpassworderror").html('Invalid New Password');
$("#newpassworderror").css("color","red");
$("#newpassword").css("border-color","red");
valid=false;
}
else
{
$("#newpassworderror").html('New Password');
$("#newpassworderror").css("color","black");
$("#newpassword").css("border-color","#ddd");
}
if(metadis.length<6)
{
$("#newpassworderror").html('Invalid New Password');
$("#newpassworderror").css("color","red");
$("#newpassword").css("border-color","red");
valid=false;
}
else
{
$("#newpassworderror").html('New Password');
$("#newpassworderror").css("color","black");
$("#newpassword").css("border-color","#ddd");
}



var mymethod="post";
var myurl="myphp.php";
var mydata="oldpassword="+oldpassword+"&newpassword="+newpassword+"&cpassword="+cpassword+"&change=yes";

$.ajax({
	
	method:mymethod,
	url:myurl,
	data:mydata,
	success:function(result)
	{
		if(result==1)
		{
	        alert("Password Changed Successfully");
			$("#oldpassword").val("");
			$("#newpassword").val("");
			$("#cpassword").val("");
		}
		else
		{
			alert(result);
		}
			
		
	}
});	






return false;
});
});














</script>-->
























</body>
</html>