<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{
	
}
else
{
	header("location:login.php");
}
$query="select * from category";
//$query1="select * from price";
$result=select($query);
//$result1=select($query1);
?>
<!DOCTYPE HTML>
<html>
<?php include"head.php";?> 
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.php">Home</a></li>
<li class="active">Add Question</li>
</ol>
</div>
<div class="graph-visual tables-main">
<h2 class="inner-tittle" style="font-family:Times New Roman;">Question</h2>
<div class="graph" style="background-image:url('https://www.knoxalliance.store/wp-content/uploads/2017/05/light-color-background-images-for-website-top-hd-images-for-free-background-for-website-in-light-color-1-1024x640.jpg');">
<div class="block-page">
<div class="container">
<div class="row">
<a href="add_cat.php"><button  class="btn btn-success btn-sm">Add Main Category</button></a>
<div class="col-lg-6">
<form method="post" enctype="multipart/form-data">
<div class="form-group" style="color:black;font-size:13pt;">choose any one
<select name="category" class="form-control" size="1" style="color:black;">
<option>choose any one</option>
<?php
$t=select("select * from category where status='1'");
while($r=mysqli_fetch_array($t))
{extract($r);
?>
<option value="<?=$id?>"><?=$r['category_name']?></option>
<?php
}
?>
<select>
</div>

<p style="color:black;font-size:13pt;">
Type the question</p>

<input type="text" name="english" class="form-control" placeholder="Question" required style="color:black;"></br>





</br></br>
<div class="col-lg-8">
 <p style="color:black;font-size:13pt;">
Options</p>

<input type="text" name="engopone" class="form-control" placeholder="Option-1" required style="color:black;"></br>
<input type="text" name="engoptwo" class="form-control" placeholder="Option-2" required style="color:black;"></br>
<input type="text" name="engopthree" class="form-control" placeholder="Option-3" required style="color:black;"></br>
<input type="text" name="engopfour" class="form-control" placeholder="Option-4" required style="color:black;"></br>

</div>
<div class="col-lg-4">
<p style="color:black;font-size:13pt;">
Correct answer</p>
<input type="text" class="form-control" name="correct"  placeholder="Correct" required style="color:black;"></br>Number Of Correct Answer
<input type="text" class="form-control" name="ans"  placeholder="Number of Correct Answer" style="color:black;"></br></br></br>


</div>
<input type="submit" name="submit" value="Sumbit" class="btn  btn-primary"  >
</div>





</form>

<?php
if(isset($_REQUEST['submit']))
{
	
	
	extract($_REQUEST);
             $query="INSERT INTO question (`cat_id`,`ques_text`) VALUES 
		   ('$category','$english')"; 
	   
              $n=iud($query);
	 if($n==1)
	 {
		 $result=select("select QuestionID from question where QuestionID=(select max(QuestionID) from question)");
		 while($r=mysqli_fetch_array($result))
		 {
			 extract($r);
		 }
		//$check=implode(", ", $_POST['category']);
		//$check1 = explode(',', $check);
		$q=$QuestionID;
 
               
              //$n=iud($query);
		 if($n==1)
		 {
	
   
   
	 
	  $query="INSERT INTO `options`(`QuestionID`, `option_1`,`option_2`,`option_3`,`option_4`,`Correct`,`ans`)  
	VALUES ('$q','$engopone','$engoptwo','$engopthree','$engopfour','$correct','$ans')";
	
	$n=iud($query);
	 if($n>=1)
	 {
		
		 echo"<script>alert('Uploaded Successfully');</script>";
		 echo "<script>window.location.href='ques_view_eng.php'</script>";
		 
		 
	 }
	
	
	else
	{
		echo"Something Wrong Try Again wwwwww";
	}
	 
		 }
		 else
		 {
			 echo"Something Wrong Try Again vvvvvv";
		 }
	 }
	
	
	else
	{
		echo"Something Wrong Try Again";
	}
}
?>





</div>
</div>



</div>

</div>

</div>
</div>
<?php include"footer.php"?>
</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
</body>
</html>