<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{
	
}
else
{
	header("location:login.php");
}
$query="select * from category";
$query1="select * from price";
$result=select($query);
$result1=select($query1);
?>
<!DOCTYPE HTML>
<html>
<?php include"head.php";?> 
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.html">Home</a></li>
<li class="active"><a href="select_languge.php">Add Question</a></li>
</ol>
</div>
<div class="graph-visual tables-main">
<h2 class="inner-tittle">Fill The Form</h2>
<div class="graph">
<div class="block-page">
<div class="container">
<div class="row">
<div class="col-lg-6">
<form method="post" enctype="multipart/form-data">
Type in Hindi-
</br></br>
<input type="text" name="hindi" class="form-control" placeholder="Question in Hindi" required></br>
Time
<input type="text" name="time" class="form-control" placeholder="Time" required></br>

Image
<input type="file" name="image" class="form-control" ></br>
<p style="font-weight:bold">Select Category--</p>
<?php
while($r=mysqli_fetch_array($result))
{
	extract($r);
	?>
	
	
	
	<input type="checkbox"  name="category[]" value="<?=$CategoryID?>" /><?=$Name?>&nbsp;&nbsp;&nbsp;

	<?php
}
?> </br></br>
<p style="font-weight:bold">Select Price--</p>
<?php
while($r1=mysqli_fetch_array($result1))
{
	extract($r1);
	?>
	
	
	
	<input type="checkbox"  name="price[]" value="<?=$PriceID?>" /><?=ucwords($Price)?> /- &nbsp;&nbsp;&nbsp;

	<?php
}
?> 

</br></br>

</div>
<div class="col-lg-4">
IN Hindi</br></br>

<input type="text" name="hindiopone" class="form-control" placeholder="Option-1" required></br>
<input type="text" name="hindioptwo" class="form-control" placeholder="Option-2" required></br>
<input type="text" name="hindiopthree" class="form-control" placeholder="Option-3" required></br>
<input type="text" name="hindiopfour" class="form-control" placeholder="Option-4" required></br>

</div>
<div class="col-lg-2">

Correct</br></br>
<input type="checkbox" name="correcthindione" value="1" ></br></br></br>
<input type="checkbox" name="correcthinditwo" value="1"></br></br></br>
<input type="checkbox" name="correcthindithree" value="1"></br></br></br>
<input type="checkbox" name="correcthindifour" value="1"></br>
</div>

<input type="submit" name="submit" value="Sumbit" class="btn btn-block btn-primary"  >
</form>

<?php
if(isset($_REQUEST['submit']))
{
	//$name="NULL";
	$error=$_FILES["image"]["error"];

$name=$_FILES["image"]["name"];
$type=$_FILES["image"]["type"];
$size=$_FILES["image"]["size"];
$tmp_name=$_FILES["image"]["tmp_name"];
  

	move_uploaded_file($tmp_name,"images/$name");
	
	extract($_REQUEST);
            $query="INSERT INTO question (`Hindi`, `Image`,`Time`) VALUES 
		   ('$hindi','$name','$time')";     
              $n=iud($query);
	 if($n==1)
	 {
		 $result=select("select QuestionID from question where QuestionID=(select max(QuestionID) from question)");
		 while($r=mysqli_fetch_array($result))
		 {
			 extract($r);
		 }
		$check=implode(", ", $_POST['category']);
		$check1 = explode(',', $check);
		$q=$QuestionID;
 $p=implode(", ", $_POST['price']);
 
$ps = explode(',', $p);
		 foreach ($ps as $p )

{
	foreach ($check1 as $check )
	{
	$n=iud("INSERT INTO `question_detail`( `PriceID`, `CategoryID`, `QuestionID`) VALUES  ('$p','$check','$q')");
	
	}
	}
         
             // $n=iud($query);
		 if($n==1)
		 {
			 $hindicoone = (isset($_REQUEST['correcthindione']));
    if ($hindicoone == 1 )
      {
        $hindicoone = 1;
      }
    else
     {
       $hindicoone = 0;
     }
  // echo $hindicoone;
   $hindicotwo = (isset($_REQUEST['correcthinditwo']));
    if ($hindicotwo == 1 )
      {
        $hindicotwo = 1;
      }
    else
     {
       $hindicotwo = 0;
     }
   //echo $hindicotwo;
   $hindicothree = (isset($_REQUEST['correcthindithree']));
    if ($hindicothree == 1 )
      {
        $hindicothree = 1;
      }
    else
     {
       $hindicothree = 0;
     }
   //echo $hindicothree;
   $hindicofour = (isset($_REQUEST['correcthindifour']));
    if ($hindicofour == 1 )
      {
        $hindicofour = 1;
      }
    else
     {
       $hindicofour = 0;
     }
	  $query="INSERT INTO `options`(`QuestionID`, `Hindi`,  `Correct`, `optionname`)  
	VALUES ('$q','$hindiopone',b'$hindicoone','answer1' ),
	('$q','$hindioptwo',b'$hindicotwo','answer2' ),
	('$q','$hindiopthree',b'$hindicothree','answer3' ),
	('$q','$hindiopfour',b'$hindicofour','answer4' ) ";
	
	$n=iud($query);
	 if($n>=1)
	 {
		
		 echo"<script>alert('Options uploaded successfully');</script>";
		 echo "<script>window.location.href='ques_view_hindi.php'</script>";
		 
		 
	 }
	 else
	{
		echo"Something Wrong Try Again wwwwww";
	}
	 
		 }
		 else
		 {
			 echo"Something Wrong Try Again vvvvvv";
		 }
	 }
	
	
	else
	{
		echo"Something Wrong Try Again";
	}
}
?>





</div>
</div>



</div>

</div>

</div>
</div>
<?php include"footer.php"?>
</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
</body>
</html>