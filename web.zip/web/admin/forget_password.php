<?php require_once"dbconfig.php";


?>
<!DOCTYPE HTML>
<html>
<?php include"head.php";?> 
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.html">Home</a></li>
<li class="active">Blank Page</li>
</ol>
</div>
<div class="graph-visual tables-main">
<h2 class="inner-tittle">forget</h2>
<div class="graph">
<div class="block-page">
<p>
<h3 class="inner-tittle two">forget </h3>
<div class="grid-1">
<div class="form-body">
<form class="form-horizontal" action="myphp.php" method="post"> 


<div class="form-group"> 
<label for="inputEmail3"  id="emailerror" class="col-sm-2 control-label">Email</label> 
<div class="col-sm-9">
<input type="text" class="form-control" id="email" name="email" placeholder="Email"> 
</div> 
</div>


<div class="col-sm-offset-2"> 
<input type="submit" class="btn btn-default" name="forget" id="forget" value="forget"> </div> </form> 
</div>

</div>
</p>
</div>

</div>

</div>
</div>
<?php include"footer.php";?>

</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
<script>

$(document).ready(function(){
$("#forget").click(function(){
var valid=true;

var email=$.trim($("#email").val());
var email_r=/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i;



if(!(email_r.test(email)))
{
$("#emailerror").html('Invalid Email');
$("#emailerror").css("color","red");
$("#email").css("border-color","red");
valid=false;
}
else
{
$("#emailerror").html('Email');
$("#emailerror").css("color","black");
$("#email").css("border-color","#ddd");
}


var mymethod="post";
var myurl="myphp.php";
var mydata="email="+email+"&forget=yes";

$.ajax({
	
	method:mymethod,
	url:myurl,
	data:mydata,
	success:function(result)
	{
		alert(result);
		if(result==1)
		{
			alert('otp sent chack your email id');
			window.location="reset_password.php";
			
			
			
		}
		else
		{
			alert("invalid email");
		}
			
		
	}










});	






return false;
});
});














</script>
























</body>
</html>