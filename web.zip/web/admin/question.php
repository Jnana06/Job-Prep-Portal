<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{
	
}
else
{
	header("location:login.php");
}
$query="select * from category";
$query1="select * from price";
$result=select($query);
$result1=select($query1);
?>
<!DOCTYPE HTML>
<html>
<?php include"head.php";?> 
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.html">Home</a></li>
<li ><a href="select_languge.php">Add Question</a></li>
</ol>
</div>
<div class="graph-visual tables-main">
<h2 class="inner-tittle">Fill The Form</h2>
<div class="graph">
<div class="block-page">
<div class="container">
<div class="row">
<div class="col-lg-6">
<form method="post" enctype="multipart/form-data">
<?php
//while($r=mysqli_fetch_array($result))
//{
	//extract($r);
	?>
	
	<!--
	<input type="checkbox"  name="category[]" value="" />&nbsp;&nbsp;&nbsp;
-->
	<?php
//}
?> 


Type in English-
<input type="text" name="english" class="form-control" placeholder="Question in English" required></br>
Type in Hindi-
<input type="text" name="hindi" class="form-control" placeholder="Question in Hindi" required></br>
Time-
<input type="text" name="time" class="form-control" placeholder="Time" required></br>
image-

<input type="file" name="image" class="form-control" ></br>
</div>
<div class="col-lg-6">
<p style="font-weight:bold">Select Category--</p>
<?php
while($r=mysqli_fetch_array($result))
{
	extract($r);
	?>
	
	
	
	<input type="checkbox"  name="category[]" value="<?=$CategoryID?>" /><?=$Name?>&nbsp;&nbsp;&nbsp;

	<?php
}
?> </br></br>
<p style="font-weight:bold">Select Price--</p>
<?php
while($r1=mysqli_fetch_array($result1))
{
	extract($r1);
	?>
	
	
	
	<input type="checkbox"  name="Price[]" value="<?=$PriceID?>" /><?=$Price?>/-&nbsp;&nbsp;&nbsp;

	<?php
}
?> 
</div>
</div>
<div class="row">
<div class="col-lg-4">
ENGLISH-</br></br>
<input type="text" name="engopone" class="form-control" placeholder="Option-1" required></br>
<input type="text" name="engoptwo" class="form-control" placeholder="Option-2" required></br>
<input type="text" name="engopthree" class="form-control" placeholder="Option-3" required></br>
<input type="text" name="engopfour" class="form-control" placeholder="Option-4" required></br>
</div>
<div class="col-lg-1">

</div>
<div class="col-lg-4">
HINDI-</br></br>
<input type="text" name="hindiopone" class="form-control" placeholder="Option-1" required></br>
<input type="text" name="hindioptwo" class="form-control" placeholder="Option-2" required></br>
<input type="text" name="hindiopthree" class="form-control" placeholder="Option-3" required></br>
<input type="text" name="hindiopfour" class="form-control" placeholder="Option-4" required></br>

</div>
<div class="col-lg-1">
Correct-</br></br>
<input type="checkbox" name="correctone" value="1" ></br></br></br>
<input type="checkbox" name="correcttwo" value="1"></br></br></br>
<input type="checkbox" name="correctthree" value="1"></br></br></br>
<input type="checkbox" name="correctfour" value="1"></br>
</div>
</div>
<input type="submit" name="submit" value="Sumbit" class="btn  col-lg-10 btn-primary"  >
</form>

<?php
if(isset($_REQUEST['submit']))
{
	//$name="NULL";
	$error=$_FILES["image"]["error"];

$name=$_FILES["image"]["name"];
$type=$_FILES["image"]["type"];
$size=$_FILES["image"]["size"];
$tmp_name=$_FILES["image"]["tmp_name"];
  
//$checkBox = $_POST['category'];
 //$check=implode(", ", $_POST['category']);



/*for ($i=0; $i<sizeof($checkBox); $i++)
        {
			
			$c=$checkBox[$i];
			
			  
			  
           // mysql_query($query) or die (mysql_error() );
        }*/
	/*echo $query="INSERT INTO `question`( `English`, `Hindi`, `Price`, `CategoryID`, `Image`) 
	VALUES ('$english','$hindi','$price','$cat','$name' ) ";*/
	move_uploaded_file($tmp_name,"images/$name");
	//echo $c;
	extract($_REQUEST);
	
            ECHO $query="INSERT INTO question (`English`, `Hindi`, `Image`, `Time`) VALUES 
		   ('$english','$hindi','$name','$time')";     
              $n=iud($query);
	 if($n==1)
	 {
		 $result=select("select QuestionID from question where QuestionID=(select max(QuestionID) from question)");
		 while($r=mysqli_fetch_array($result))
		 {
			 extract($r);
		 }
		$check=implode(", ", $_POST['category']);
		$check1 = explode(',', $check);
		$q=$QuestionID;
 $p=implode(", ", $_POST['Price']);
 
$ps = explode(',', $p);
foreach ($ps as $p )

{
	foreach ($check1 as $check )
	{
		
	$n=iud("INSERT INTO `question_detail`( `PriceID`, `CategoryID`, `QuestionID`) VALUES  ('$p','$check','$q')");
	
	}
	}

            //$query="INSERT INTO `queswcat`( `Priceid`, `Categoryid`, `Questionid`) VALUES 
		      
              
			   if($n==1)
	 {
		 $engcoone = (isset($_REQUEST['correctone']));
    if ($engcoone == 1 )
      {
        $engcoone = 1;
      }
    else
     {
       $engcoone = 0;
     }
  // echo $engcoone;
   $engcotwo = (isset($_REQUEST['correcttwo']));
    if ($engcotwo == 1 )
      {
        $engcotwo = 1;
      }
    else
     {
       $engcotwo = 0;
     }
   //echo $engcotwo;
   $engcothree = (isset($_REQUEST['correctthree']));
    if ($engcothree == 1 )
      {
        $engcothree = 1;
      }
    else
     {
       $engcothree = 0;
     }
   //echo $engcothree;
   $engcofour = (isset($_REQUEST['correctfour']));
    if ($engcofour == 1 )
      {
        $engcofour = 1;
      }
    else
     {
       $engcofour = 0;
     }
   //echo $engcothree;
   /*$hindicoone = (isset($_REQUEST['correcthindione']));
    if ($hindicoone == 1 )
      {
        $hindicoone = 1;
      }
    else
     {
       $hindicoone = 0;
     }
  // echo $hindicoone;
   $hindicotwo = (isset($_REQUEST['correcthinditwo']));
    if ($hindicotwo == 1 )
      {
        $hindicotwo = 1;
      }
    else
     {
       $hindicotwo = 0;
     }
   //echo $hindicotwo;
   $hindicothree = (isset($_REQUEST['correcthindithree']));
    if ($hindicothree == 1 )
      {
        $hindicothree = 1;
      }
    else
     {
       $hindicothree = 0;
     }
   //echo $hindicothree;
  $hindicofour = (isset($_REQUEST['correcthindifour']));
    if ($hindicofour == 1 )
      {
        $hindicofour = 1;
      }
    else
     {
       $hindicofour = 0;
     }*/
	  $query="INSERT INTO `options`(`QuestionID`, `English`,`Hindi`, `Correct`, `optionname`)  
	VALUES ('$q','$engopone','$hindiopone',b'$engcoone','answer1' ),
	('$q','$engoptwo','$hindioptwo',b'$engcotwo','answer2' ),
	('$q','$engopthree','$hindiopthree',b'$engcothree','answer3'),
	('$q','$engopfour','$hindiopfour',b'$engcofour','answer4' ) ";
	
	$n=iud($query);
	 if($n>=1)
	 {
		
		 echo"<script>alert('Options uploaded successfully');</script>";
		 echo "<script>window.location.href='question_view.php'</script>";
		 
		 
	 }
		 
	 else
	{
		echo"Something Wrong Try Again wwwwww";
	}
	 
		 }
		 else
		 {
			 echo"Something Wrong Try Again vvvvvv";
		 }
	 }
	
	
	else
	{
		echo"Something Wrong Try Again";
	}
}
?>






</div>



</div>

</div>

</div>
</div>
<?php include"footer.php"?>
</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
</body>
</html>