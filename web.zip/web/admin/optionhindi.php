<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{
	
}
else
{
	header("location:login.php");
}

?>
<!DOCTYPE HTML>
<html>
<?php include"head.php";?> 
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.html">Home</a></li>
<li class="active">Add Question</li>
</ol>
</div>
<div class="graph-visual tables-main">
<h2 class="inner-tittle">Select Any Category</h2>
<div class="graph">
<div class="block-page">
<div class="container">
<div class="row">

<form method="post" enctype="multipart/form-data"> 
<div class="col-lg-4">
IN Hindi</br></br></br>

<input type="text" name="hindiopone" class="form-control" placeholder="Option-1" required></br>
<input type="text" name="hindioptwo" class="form-control" placeholder="Option-2" required></br>
<input type="text" name="hindiopthree" class="form-control" placeholder="Option-3" required></br>
<input type="text" name="hindiopfour" class="form-control" placeholder="Option-4" required></br>

</div>
<div class="col-lg-4">

Hindi Correct
</br> Answer</br></br>
<input type="checkbox" name="correcthindione" value="1" ></br></br></br>
<input type="checkbox" name="correcthinditwo" value="1"></br></br></br>
<input type="checkbox" name="correcthindithree" value="1"></br></br></br>
<input type="checkbox" name="correcthindifour" value="1"></br>
</div>

<input type="submit" name="submit" value="Sumbit" class="btn col-lg-9 btn-primary"  >
</form>






</div>
</div>

<?php
   $hindicoone = (isset($_REQUEST['correcthindione']));
    if ($hindicoone == 1 )
      {
        $hindicoone = 1;
      }
    else
     {
       $hindicoone = 0;
     }
  // echo $hindicoone;
   $hindicotwo = (isset($_REQUEST['correcthinditwo']));
    if ($hindicotwo == 1 )
      {
        $hindicotwo = 1;
      }
    else
     {
       $hindicotwo = 0;
     }
   //echo $hindicotwo;
   $hindicothree = (isset($_REQUEST['correcthindithree']));
    if ($hindicothree == 1 )
      {
        $hindicothree = 1;
      }
    else
     {
       $hindicothree = 0;
     }
   //echo $hindicothree;
   $hindicofour = (isset($_REQUEST['correcthindifour']));
    if ($hindicofour == 1 )
      {
        $hindicofour = 1;
      }
    else
     {
       $hindicofour = 0;
     }
	 
if(isset($_REQUEST['submit']))
{
	
extract($_REQUEST);
 
	 $query="INSERT INTO `option`( `QuestionID`, `Hindi`, `CorrectHindi`)  
	VALUES ('$id','$hindiopone',b'$hindicoone' ),
	('$id','$hindioptwo',b'$hindicotwo' ),
	('$id','$hindiopthree',b'$hindicothree' ),
	('$id','$hindiopfour',b'$hindicofour' ) ";
	
	$n=iud($query);
	 if($n>=1)
	 {
		
		 echo"<script>alert('Options uploaded successfully');</script>";
		 echo "<script>window.location.href='question_view.php'</script>";
		 
		 
	 }
	
	
	else
	{
		echo"Something Wrong Try Again";
	}
}
?>


</div>

</div>

</div>
</div>
<?php include"footer.php"?>
</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>
</body>
</html>