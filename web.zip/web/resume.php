<?php require_once"dbconfig.php";?>
<!DOCTYPE HTML>
<html>
<head>
<title>JobPrep Portal</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Seeking Responsive web template"/>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
<script>
$(document).ready(function(){
	//alert('aaaaaaaa');
	$('a').click(function(){
    var propty= $(this); 
    var action =propty.attr("data-action");
    });
});

	</script>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!----font-Awesome----->
</head>
<body>
<?php include"nav.php";?>

<div class="banner_1">
	<div class="container">
		<div id="search_wrapper1">
		   
		</div>
   </div> 
</div>	
<div class="container">
    <div class="single">  
	   <div class="col-md-4">
	   	  <div class="col_3">
		  
		  </br>
		  </br>
		  </br>
		  </br>
		  </br>
		  </br>
	   	  	<a href="tips.php" style="text-decoration:none" ><h3>Tips</h3></a>
	   	  	
			
	   	  </div>
	   	  
	   	 
	 </div>
	 <a href="sample-smart-and-balanced-resume.pdf"><div class="col-md-4">
	 <img 
	 src="https://image.slidesharecdn.com/6088ac51-8c51-4fcd-b953-4df1ad4aed18-160329075902/95/formal
	 resumemykha-1-1-638.jpg?cb=1459238355" style="height:400px">
	 <button class="btn btn-success">View</button></div></a>
	 <a href="Software Engineer Fresher Resume.pdf"><div class="col-md-4">
	 <img 
	 src="https://i.pinimg.com/originals/75/5a/e9/755ae93b7b6f0a96c3afd2e241004245.jpg" style="height:400px"><button class="btn btn-success">View</button></div></a>
	
  <div class="clearfix"> </div>
 </div>
</div>

<div class="footer_bottom">	
  
  	
  	<div class="clearfix"> </div>
	<div class="copy">
		<p style="font-size:15pt;"><b><em> “ The best preparation for tomorrow is doing your best today. ”</em></b> </p>
	</div>
  </div>
</div>
</body>
</html>	