<nav class="navbar navbar-default" role="navigation">
	<div class="container">
	    <div class="navbar-header">
	        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
	        </button>
	        <a class="navbar-brand" href="index.php"><span style="color:white;font-weight:bold;font-size:30px;"> Job-Prep Portal</span></a>
	    </div>
	    <!--/.navbar-header-->
	    <div class="navbar-collapse collapse" id="bs-example-navbar-collapse-1" style="height: 1px;">
	        <ul class="nav navbar-nav">
			<?php
			if(isset($_SESSION['id']))
			{
				?>
				<li><a href="apptitude.php">Aptitude</a></li>
		      
		        <li><a href="location.php">Subjects</a></li>
		        <li><a href="companies.php">Companies</a></li>
				 <li><a href="resume.php">Resume</a></li>
				
				<li class="dropdown">
		            <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="font-weight:bold;color:black"><?=ucwords($_SESSION['name'])?><b class="caret"></b></a>
		            <ul class="dropdown-menu">
			            <li><a href="update_profile.php">Update Profile</a></li>
			            <li><a href="logout.php">Logout</a></li>
				<?php
			}else
			{
				?>
				<li><a href="admin/login.php">Admin</a></li>
				 <li><a href="login.php">Signin</a></li>
		        <li><a href="register.php">Register</a></li>
				<?php
			}
			
			?>
		        
		        
		        
		        
		         
			            
		            </ul>
		        </li>
	        </ul>
	    </div>
	    <div class="clearfix"> </div>
	  </div>
	    <!--/.navbar-collapse-->
	</nav>