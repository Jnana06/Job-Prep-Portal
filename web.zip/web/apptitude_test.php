<?php require_once"dbconfig.php";?>
<!DOCTYPE HTML>
<html>
<head>
<title>JobPrep Portal</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Seeking Responsive web template"/>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
<script>
$(document).ready(function(){
	
	$('a').click(function(){
    var propty= $(this); 
    var action =propty.attr("data-action");
    });
});

	</script>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!----font-Awesome----->
</head>
<body>
<?php include"nav.php";?>

<div class="banner_1">
	<div class="container">
		<div id="search_wrapper1">
		   
		</div>
   </div> 
</div>	
<div class="container-fluid">
    <div class="row">  
	   <div class="col-md-3">
	   	  <div class="col_3">

		  
	<h2>Topics</h2>   	  	

<?php
$t=select("SELECT * FROM category where status='1' ");
while($y=mysqli_fetch_array($t))
{
	extract($y);
	
?>

<a href="#" ux=<?=$id?> class="deleteText" style="text-decoration:none"><h3><?=$category_name?></h3></a>





<?php
}

?>
<div>
</br>


</div>
</div>
</div></br></br>
		  <div class="col-md-9"><div class="col_3">

		  <div id="pera">
		  </div>
	   	  	<div id="pera1" class="pl">
	   	  	</div>
			
	   	  </div>
	   	 
	   	  
	   	 
	 </div>
	 
  <div class="clearfix"> </div>
 </div>
</div>

<div class="footer_bottom">	
  <script>
	$(document).on("click", "a.deleteText", function() {
  
        
		var id=$(this).attr('ux');
		$.ajax({
			
			
			url:"app.php",
			method:"post",
		data:{id:id},
		datatype:"text",
		success:function(data)
		{
			$(pera).html(data);
			 $("#pera1").css("display","none");
		}
		});
    
});


$(document).on("click", "a.quiz", function() {
   
        
		var id=$(this).attr('ux');
	
		$.ajax({
			
			
			url:"quiz.php",
			method:"post",
		data:{id:id},
		datatype:"text",
		success:function(data)
		{
			$(pera1).html(data);
			$("#pera1").css("display","block");
		}
		});
    
});



























	</script>
  	
  	<div class="clearfix"> </div>
	<div class="copy">
		<p style="font-size:15pt;"><b><em> “ The best preparation for tomorrow is doing your best today. ”</em></b> </p>
	</div>
  </div>
</div>
</body>
</html>	