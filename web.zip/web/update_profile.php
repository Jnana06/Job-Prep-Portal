<?php require_once"dbconfig.php";?>
<!DOCTYPE HTML>
<html>
<head>
<title>JobPrep Portal</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Seeking Responsive web template"/>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
<!----font-Awesome----->
<link href="css/font-awesome.css" rel="stylesheet"> 
<style>
.field-icon {
  float: right;
  margin-left: -25px;
  margin-top: -25px;
  position: relative;
  z-index: 2;
}

.container{
  padding-top:50px;
  margin: auto;
}
</style>
</head>
<body>
<?php include"nav.php";?>

<div class="banner_1">
	<div class="container">
		
   </div> 
</div>	
<div class="container">
    <div class="single">  
	   <div class="form-container">
        <h2>Update Profile</h2>
        <form method="post" action="myphp.php">
          <div class="row">
		 <?php $r=select("select * from register where id='".$_SESSION['id']."'");
		  while($a=mysqli_fetch_array($r))
		  {extract($a);
		  ?>
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="firstName"> Name</label>
                <div class="col-md-9">
                    <input type="text" path="firstName" name="name" value="<?=$name?>" id="firstName" class="form-control input-sm"/>
                </div>
            </div>
         </div>
         
        <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="lastName">Mobile Number</label>
                <div class="col-md-9">
                    <input type="text" path="lastName"  name="mobile" value="<?=$mobile?>" id="lastName" pattern="[0-9]{10}" class="form-control input-sm"/>
                    <input type="hidden" path="lastName"  name="id" value="<?=$id?>" id="lastName" class="form-control input-sm"/>
                </div>
            </div>
        </div>
        
        
        <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="email">Email</label>
                <div class="col-md-9">
                    <input type="email" path="email" id="email" value="<?=$email?>"  name="email" class="form-control input-sm"/>
                </div>
            </div>
        </div><div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="password">Password</label>
                <div class="col-md-9">
                    <input type="password" path="email" id="password-field"   value="<?=$password?>" name="password"  class="form-control input-sm"/>
               <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password">
			   </div>
            </div>
        </div>
        
		
		
        
        
        
        <div class="row">
            <div class="form-actions floatRight">
                <input type="submit" value="Update" name="update" class="btn btn-primary btn-sm">
            </div>
        </div>
		<?php
		  }
		?>
    </form>
    </div>
 </div>
</div>
<script>
$(".toggle-password").click(function() {

  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});
</script>
<div class="footer_bottom">	
  <div class="container">
    
  	<div class="clearfix"> </div>
	<div class="copy">
		<p style="font-size:15pt;"><b><em> “ The best preparation for tomorrow is doing your best today. ”</em></b> </p>
	</div>
  </div>
</div>
</body>
</html>	