<?php require_once"dbconfig.php";?>
<!DOCTYPE HTML>
<html>
<head>
<title>JobPrep Portal</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="keywords" content="Seeking Responsive web template"/>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
<!----font-Awesome----->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!----font-Awesome----->
</head>
<body>
<?php include"nav.php";?>

<div class="banner_1">
	<div class="container">
		
   </div> 
</div>	
<div class="container">
    <div class="single">  
	   <div class="col-md-4">
	   	  <div class="col_3">
		  <?php $r=select("select * from data where subject_id='".$_REQUEST['id']."'");
		  while($a=mysqli_fetch_array($r))
		  {extract($a);
		  ?>
		  <a href="#" ux=<?=$id?> class="deleteText" style="text-decoration:none"><span class="delete-icon"> <h3><?=$title?></h3></span></a>
	   	  	<?php
		  }
			?>
	   	  </div>
	   	  
	   	 

	 </div>
	 <div class="col-md-8 single_right">
	      <div class="but_list">
	       <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
			<ul id="myTab" class="nav nav-tabs" role="tablist">
			  <!--<li role="presentation" class=""><a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true"></a></li>
			  <li role="presentation"><a href="#profile" role="tab" id="profile-tab" data-toggle="tab" aria-controls="profile"></a></li>-->
			</ul>
		
			 
			 <div id="myTabContent" class="tab-content">
		  <div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
		    
			 <div class="tab_grid">
			    
			    <div class="col-sm-12">
			       <div class="location_box1">
			    	 <p id="pera"></p>
			    	 
				   </div>
			    </div>
			    <div class="clearfix"> </div>
			 </div> </div>
		  
	  </div>
			 
			
			 
			 
			 
			 
			 
			 
		 
     </div>
    </div>
   </div>
  <div class="clearfix"> </div>
 </div>
</div>

<div class="footer_bottom">	
  <div class="container">
    <script>
	$(document).on("click", "a.deleteText", function() {
   
        
		var id=$(this).attr('ux');
		$.ajax({
			
			
			url:"test.php",
			method:"post",
		data:{id:id},
		datatype:"text",
		success:function(data)
		{
			$(pera).html(data);
		}
		});
    
});



	</script>
  	
  	<div class="clearfix"> </div>
	<div class="copy">
		<p style="font-size:15pt;"><b><em> “ The best preparation for tomorrow is doing your best today. ”</em></b> </p>
	</div>
  </div>
</div>
</body>
</html>	